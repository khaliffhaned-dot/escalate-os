import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen bg-[#0a0a0a] text-neutral-100 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-40 left-1/4 w-[700px] h-[700px] bg-emerald-500/[0.07] rounded-full blur-3xl" />
        <div className="absolute top-20 -right-40 w-[500px] h-[500px] bg-teal-500/[0.06] rounded-full blur-3xl" />
      </div>

      <nav className="relative z-10 max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-2.5 font-semibold tracking-tight">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-[#0a0a0a] text-sm font-bold">E</div>
          <span>Escalate MY</span>
        </div>
        <div className="flex items-center gap-5 text-sm">
          <Link href="/login" className="text-neutral-300 hover:text-white transition">Sign in</Link>
          <Link href="/dashboard" className="px-4 py-2 bg-emerald-500 text-[#0a0a0a] rounded-full text-sm font-medium hover:bg-emerald-400 active:scale-[0.98] transition">
            Launch Dashboard
          </Link>
        </div>
      </nav>

      <section className="relative z-10 max-w-3xl mx-auto px-6 pt-16 pb-10 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/20 bg-emerald-500/10 text-xs text-emerald-300 mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          Crisis Governance Platform
        </div>
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-semibold tracking-tight leading-[1.05]">
          The First Hour<br />Decides Everything.
        </h1>
        <p className="mt-6 text-lg text-neutral-400 leading-relaxed">
          Govern critical incidents with structured workflows for regulatory obligations, executive decisions, evidence records and board reporting.
        </p>
        <div className="mt-10 flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/dashboard" className="px-6 py-3 bg-emerald-500 text-[#0a0a0a] rounded-full text-sm font-medium hover:bg-emerald-400 active:scale-[0.98] transition inline-flex items-center justify-center gap-2">
            Enter Situation Room <span aria-hidden>→</span>
          </Link>
          <Link href="/login" className="px-6 py-3 border border-neutral-700 rounded-full text-sm hover:bg-white/5 transition">
            Sign in
          </Link>
        </div>
      </section>

      <section className="relative z-10 max-w-5xl mx-auto px-6 pb-16">
        <div className="rounded-2xl border border-white/[0.08] bg-neutral-900/50 backdrop-blur-xl shadow-2xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-white/[0.06] bg-black/30">
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
            </div>
            <span className="text-xs text-neutral-500 ml-2">Situation Room</span>
          </div>
          <div className="p-5 grid md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-2.5">
              <div className="text-[11px] uppercase tracking-wider text-neutral-500">Active Incidents</div>
              {[
                { t: "Regulatory inquiry — media coverage", s: "serious" },
                { t: "Stakeholder request — board briefing", s: "moderate" },
                { t: "Cyber incident — customer data", s: "critical" },
              ].map((r) => (
                <div key={r.t} className="flex items-center justify-between rounded-lg border border-white/[0.06] bg-black/30 px-4 py-3 text-sm">
                  <span className="truncate pr-3">{r.t}</span>
                  <span className={`text-[11px] px-2 py-0.5 rounded-md capitalize ${r.s === "critical" ? "bg-red-950 text-red-200" : r.s === "serious" ? "bg-orange-950 text-orange-200" : "bg-amber-950 text-amber-200"}`}>{r.s}</span>
                </div>
              ))}
            </div>
            <div className="space-y-2.5">
              <div className="text-[11px] uppercase tracking-wider text-neutral-500">Regulatory Clocks</div>
              {[["BNM RMiT", "2 hrs"], ["PDPA", "≤72 hrs"], ["Bursa", "Same-day"]].map(([n, w]) => (
                <div key={n} className="flex justify-between text-xs rounded-lg border border-white/[0.06] bg-black/30 px-3 py-2.5">
                  <span>{n}</span><span className="text-emerald-300">{w}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="relative z-10 border-t border-white/[0.06] py-16">
        <div className="max-w-4xl mx-auto px-6 grid md:grid-cols-2 gap-6 text-sm">
          <div className="rounded-xl border border-white/[0.06] p-6">
            <h2 className="font-medium text-neutral-300 mb-2">Media intelligence</h2>
            <p className="text-neutral-500 leading-relaxed">Helps organisations understand what is happening across news and social channels.</p>
          </div>
          <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/[0.04] p-6">
            <h2 className="font-medium mb-2">Escalate MY</h2>
            <p className="text-neutral-300 leading-relaxed">Helps organisations govern what happens next — decisions, regulatory clocks, evidence and board reporting.</p>
          </div>
        </div>
      </section>

      <footer className="relative z-10 border-t border-white/[0.06] py-8 text-center text-xs text-neutral-600">
        Escalate MY™ · Crisis Governance Platform for Malaysian Organisations
      </footer>
    </main>
  );
}
