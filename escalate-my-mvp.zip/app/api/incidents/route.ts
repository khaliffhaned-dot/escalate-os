import { NextRequest } from "next/server";
import { getDb, getSession } from "@/lib/db";
import { ok, unauthorized, forbidden, serverError, fail } from "@/lib/api";
import { assertRole } from "@/lib/security";

const SEVERITIES = ["critical", "serious", "moderate", "minor"] as const;
type Severity = typeof SEVERITIES[number];

function slaFor(sev: string): number {
  if (sev === "critical") return 120;
  if (sev === "serious") return 360;
  if (sev === "moderate") return 1440;
  return 2880;
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("session")?.value;
    const session = await getSession(token);
    if (!session) return unauthorized();
    if (!assertRole(session.role, ["admin", "operator"])) return forbidden();

    const db = await getDb();
    const body = await request.json().catch(() => ({}));

    const title = typeof body.title === "string" ? body.title.trim() : "";
    const summary = typeof body.summary === "string" ? body.summary.trim() || null : null;
    const severity: Severity = SEVERITIES.includes(body.severity) ? body.severity : "moderate";
    const incident_type = typeof body.incident_type === "string" ? body.incident_type : null;

    if (!title || title.length > 200) return fail("Invalid title", 400, "VALIDATION");

    const id = crypto.randomUUID();
    const sla = slaFor(severity);
    const now = new Date().toISOString();

    await db
      .prepare(
        `INSERT INTO incidents (id, tenant_id, title, summary, severity, incident_type, status, response_sla_minutes, created_by, classification_set_by, classification_set_at)
         VALUES (?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, ?)`
      )
      .bind(id, session.tenant_id, title, summary, severity, incident_type, sla, session.user_id, session.user_id, now)
      .run();

    await db
      .prepare(
        `INSERT INTO audit_log (id, tenant_id, actor, action, target_type, target_id, detail)
         VALUES (?, ?, ?, 'incident.created', 'incident', ?, ?)`
      )
      .bind(crypto.randomUUID(), session.tenant_id, session.email, id, JSON.stringify({ severity, incident_type }))
      .run();

    return ok({
      incident: {
        id,
        title,
        summary,
        severity,
        incident_type,
        status: "Active",
        response_sla_minutes: sla,
        created_at: now,
        owner: null,
      },
    });
  } catch (err) {
    console.error("[incidents.POST]", err);
    return serverError("Failed to create incident");
  }
}
