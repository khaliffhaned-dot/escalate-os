import { NextRequest } from "next/server";
import { getDb, getSession } from "@/lib/db";
import { ok, unauthorized, forbidden, notFound, fail, serverError } from "@/lib/api";
import { assertRole } from "@/lib/security";

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("session")?.value;
    const session = await getSession(token);
    if (!session) return unauthorized();
    if (!assertRole(session.role, ["admin", "operator"])) return forbidden();

    const db = await getDb();
    const body = await request.json().catch(() => ({}));

    const incident_id = typeof body.incident_id === "string" ? body.incident_id : "";
    const summary = typeof body.summary === "string" ? body.summary.trim() : "";

    if (!incident_id || !summary || summary.length > 2000) {
      return fail("Invalid input", 400, "VALIDATION");
    }

    const inc = await db
      .prepare("SELECT id FROM incidents WHERE id = ? AND tenant_id = ?")
      .bind(incident_id, session.tenant_id)
      .first();
    if (!inc) return notFound("Incident not found");

    const id = crypto.randomUUID();
    await db
      .prepare(`INSERT INTO decisions (id, tenant_id, incident_id, summary, recorded_by) VALUES (?, ?, ?, ?, ?)`)
      .bind(id, session.tenant_id, incident_id, summary, session.email)
      .run();

    await db
      .prepare(
        `INSERT INTO audit_log (id, tenant_id, actor, action, target_type, target_id, detail)
         VALUES (?, ?, ?, 'decision.recorded', 'decision', ?, ?)`
      )
      .bind(crypto.randomUUID(), session.tenant_id, session.email, id, JSON.stringify({ incident_id }))
      .run();

    return ok({ decision_id: id });
  } catch (err) {
    console.error("[decisions.POST]", err);
    return serverError("Failed to record decision");
  }
}
