import { NextRequest } from "next/server";
import { getDb } from "@/lib/db";
import { verifyPassword } from "@/lib/auth";
import { ok, fail, serverError } from "@/lib/api";
import { checkRateLimit } from "@/lib/rate-limit";

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get("cf-connecting-ip") || "unknown";
    const rl = await checkRateLimit(`login:${ip}`, 10, 60_000);
    if (!rl.allowed) {
      const res = fail("Too many attempts", 429, "RATE_LIMITED");
      if (rl.retryAfter) res.headers.set("Retry-After", String(rl.retryAfter));
      return res;
    }

    const db = await getDb();
    const body = await request.json().catch(() => ({}));
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";

    if (!email || !password) return fail("Missing credentials", 400, "VALIDATION");

    const user = await db
      .prepare("SELECT id, tenant_id, email, password_hash, role FROM users WHERE email = ?")
      .bind(email)
      .first<{ id: string; tenant_id: string; email: string; password_hash: string; role: string }>();

    if (!user || !(await verifyPassword(password, user.password_hash))) {
      return fail("Invalid credentials", 401, "INVALID_CREDENTIALS");
    }

    const sessionId = crypto.randomUUID();
    const expires = new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString();

    await db
      .prepare("INSERT INTO sessions (id, user_id, tenant_id, expires_at) VALUES (?, ?, ?, ?)")
      .bind(sessionId, user.id, user.tenant_id, expires)
      .run();

    const res = ok({ role: user.role });
    res.cookies.set("session", sessionId, {
      httpOnly: true,
      secure: true,
      sameSite: "strict",
      path: "/",
      maxAge: 8 * 60 * 60,
    });
    return res;
  } catch (err) {
    console.error("[auth.login]", err);
    return serverError("Login failed");
  }
}
