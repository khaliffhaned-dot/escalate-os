import { NextRequest } from "next/server";
import { getDb } from "@/lib/db";
import { ok, fail, unauthorized, serverError } from "@/lib/api";
import { checkRateLimit } from "@/lib/rate-limit";

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get("cf-connecting-ip") || "unknown";
    const rl = await checkRateLimit(`signal:${ip}`, 60, 60_000);
    if (!rl.allowed) {
      const res = fail("Rate limited", 429, "RATE_LIMITED");
      if (rl.retryAfter) res.headers.set("Retry-After", String(rl.retryAfter));
      return res;
    }

    const secret = request.headers.get("x-signal-secret");
    const expected = process.env.SIGNAL_WEBHOOK_SECRET || "";
    if (!expected || expected === "change-me-in-production" || secret !== expected) {
      return unauthorized("Invalid or missing signal secret");
    }

    const db = await getDb();
    const body = await request.json().catch(() => ({}));
    const title = typeof body.title === "string" ? body.title.trim() : "";
    const summary = typeof body.summary === "string" ? body.summary.trim() : null;
    const severity = ["critical", "serious", "moderate", "minor"].includes(body.severity)
      ? body.severity
      : "moderate";
    const source = typeof body.source === "string" ? body.source.slice(0, 100) : null;
    const external_id = typeof body.external_id === "string" ? body.external_id.slice(0, 100) : null;

    if (!title || title.length > 200) return fail("Invalid title", 400, "VALIDATION");

    const tenant_id = "tenant-demo";
    const id = crypto.randomUUID();
    const sla = severity === "critical" ? 120 : severity === "serious" ? 360 : severity === "moderate" ? 1440 : 2880;

    await db
      .prepare(
        `INSERT INTO incidents (id, tenant_id, title, summary, severity, status, response_sla_minutes, created_by)
         VALUES (?, ?, ?, ?, ?, 'Active', ?, 'signal-intake')`
      )
      .bind(id, tenant_id, title, summary, severity, sla)
      .run();

    await db
      .prepare(
        `INSERT INTO audit_log (id, tenant_id, actor, action, target_type, target_id, detail)
         VALUES (?, ?, 'signal-intake', 'incident.created', 'incident', ?, ?)`
      )
      .bind(crypto.randomUUID(), tenant_id, id, JSON.stringify({ external_id, source }))
      .run();

    return ok({ incident_id: id });
  } catch (err) {
    console.error("[signals.POST]", err);
    return serverError("Failed");
  }
}
