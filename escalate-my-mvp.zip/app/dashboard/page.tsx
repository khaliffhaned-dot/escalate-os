import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import Link from "next/link";
import { getSession } from "@/lib/db";
import SituationRoom from "./situation-room";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const token = cookies().get("session")?.value;
  const session = await getSession(token);
  if (!session) redirect("/login");

  const { getDb } = await import("@/lib/db");
  const db = await getDb();
  const { results: incidents } = await db
    .prepare(
      `SELECT id, title, summary, severity, incident_type, status, response_sla_minutes, created_at, owner
       FROM incidents WHERE tenant_id = ? ORDER BY created_at DESC LIMIT 50`
    )
    .bind(session.tenant_id)
    .all();

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-neutral-100">
      <header className="border-b border-white/[0.06] px-6 py-3.5 flex justify-between items-center sticky top-0 bg-[#0a0a0a]/80 backdrop-blur-xl z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-md bg-emerald-500 flex items-center justify-center text-[#0a0a0a] text-xs font-bold">E</div>
          <div>
            <h1 className="text-sm font-semibold leading-none">Situation Room</h1>
            <p className="text-[11px] text-neutral-500 mt-0.5">Escalate MY</p>
          </div>
        </div>
        <div className="flex items-center gap-5 text-xs">
          <Link href="/dashboard/clocks" className="text-neutral-400 hover:text-white transition">Regulatory Clocks</Link>
          <Link href="/dashboard/board" className="text-neutral-400 hover:text-white transition">BoardBrief</Link>
          <form action="/api/auth/logout" method="post">
            <button className="text-neutral-400 hover:text-white transition">Sign out</button>
          </form>
        </div>
      </header>
      <SituationRoom incidents={incidents || []} />
    </div>
  );
}
