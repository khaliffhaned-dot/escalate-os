import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import Link from "next/link";
import { getSession } from "@/lib/db";
import { REGULATORY_CLOCKS } from "@/lib/regulatory";

export const dynamic = "force-dynamic";

export default async function ClocksPage() {
  const token = cookies().get("session")?.value;
  const session = await getSession(token);
  if (!session) redirect("/login");

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-neutral-100">
      <header className="border-b border-white/[0.06] px-6 py-3.5 sticky top-0 bg-[#0a0a0a]/80 backdrop-blur-xl z-10">
        <Link href="/dashboard" className="text-xs text-neutral-500 hover:text-white transition">← Situation Room</Link>
        <h1 className="text-base font-semibold mt-1">Regulatory Clocks</h1>
        <p className="text-[11px] text-neutral-500">Reference windows · Confirm with current guidance and counsel</p>
      </header>
      <div className="max-w-3xl mx-auto p-6 space-y-3">
        {REGULATORY_CLOCKS.map((c) => (
          <div key={c.shortName} className="rounded-xl border border-white/[0.06] bg-neutral-900/30 p-4">
            <div className="flex justify-between items-start gap-4">
              <div>
                <h2 className="font-medium">{c.regulator}</h2>
                <p className="text-[11px] text-neutral-500 mt-0.5">{c.shortName}</p>
              </div>
              <span className="text-xs text-emerald-300 bg-emerald-950/50 px-2.5 py-1 rounded-md border border-emerald-900/40 shrink-0">
                {c.typicalWindow}
              </span>
            </div>
            <p className="text-sm text-neutral-400 mt-3 leading-relaxed">{c.notes}</p>
            <p className="text-[11px] text-neutral-600 mt-2">{c.source}</p>
          </div>
        ))}
        <p className="text-[11px] text-neutral-600 pt-4 leading-relaxed">
          These are reference windows drawn from publicly available regulatory frameworks. They are not legal advice. Organisations must calibrate escalation thresholds and confirm current requirements with counsel.
        </p>
      </div>
    </div>
  );
}
