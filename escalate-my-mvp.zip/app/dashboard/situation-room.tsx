"use client";

import { useState, useRef, useEffect } from "react";
import { slaForSeverity } from "@/lib/auth";

type Incident = {
  id: string;
  title: string;
  summary: string | null;
  severity: string;
  incident_type: string | null;
  status: string;
  response_sla_minutes: number | null;
  created_at: string;
  owner: string | null;
};

const SEVERITIES = ["critical", "serious", "moderate", "minor"] as const;
const TYPES = ["operational", "reputational", "legal_regulatory", "human_capital", "environmental", "cyber", "force_majeure", "other"] as const;

export default function SituationRoom({ incidents: initial }: { incidents: Incident[] }) {
  const [incidents, setIncidents] = useState(initial);
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  const [severity, setSeverity] = useState("moderate");
  const [type, setType] = useState("reputational");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [decisionFor, setDecisionFor] = useState<string | null>(null);
  const [decisionText, setDecisionText] = useState("");
  const [decisionLoading, setDecisionLoading] = useState(false);
  const [justCreated, setJustCreated] = useState<string | null>(null);
  const titleRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        titleRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  async function createIncident() {
    if (!title.trim()) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/incidents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, summary, severity, incident_type: type }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      setIncidents((prev) => [data.incident, ...prev]);
      setJustCreated(data.incident.id);
      setTimeout(() => setJustCreated(null), 1800);
      setTitle("");
      setSummary("");
      titleRef.current?.focus();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function recordDecision(incidentId: string) {
    if (!decisionText.trim()) return;
    setDecisionLoading(true);
    try {
      const res = await fetch("/api/decisions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ incident_id: incidentId, summary: decisionText }),
      });
      if (!res.ok) throw new Error("Failed");
      setDecisionText("");
      setDecisionFor(null);
    } catch {
      /* silent */
    } finally {
      setDecisionLoading(false);
    }
  }

  const badge = (sev: string) => {
    const map: Record<string, string> = {
      critical: "bg-red-950/80 text-red-200 border border-red-900/60",
      serious: "bg-orange-950/80 text-orange-200 border border-orange-900/60",
      moderate: "bg-amber-950/80 text-amber-200 border border-amber-900/60",
      minor: "bg-neutral-800 text-neutral-300 border border-neutral-700",
    };
    return map[sev] || "bg-neutral-800";
  };

  const severityDot = (sev: string) => {
    const map: Record<string, string> = {
      critical: "bg-red-400",
      serious: "bg-orange-400",
      moderate: "bg-amber-400",
      minor: "bg-neutral-500",
    };
    return map[sev] || "bg-neutral-500";
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      {/* Create card */}
      <section className="rounded-2xl border border-white/[0.08] bg-neutral-900/40 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-medium text-neutral-300">New incident</h2>
          <span className="text-[11px] text-neutral-600">⌘K to focus</span>
        </div>
        <input
          ref={titleRef}
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && createIncident()}
          placeholder="Title"
          className="w-full bg-black/40 border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition"
        />
        <textarea
          value={summary}
          onChange={(e) => setSummary(e.target.value)}
          placeholder="Summary (optional)"
          rows={2}
          className="w-full bg-black/40 border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition resize-none"
        />
        <div className="flex flex-wrap gap-2.5 items-center">
          <select value={severity} onChange={(e) => setSeverity(e.target.value)} className="bg-black/40 border border-white/[0.08] rounded-lg px-3 py-2 text-sm">
            {SEVERITIES.map((s) => (
              <option key={s} value={s}>{s} · {slaForSeverity(s)} min</option>
            ))}
          </select>
          <select value={type} onChange={(e) => setType(e.target.value)} className="bg-black/40 border border-white/[0.08] rounded-lg px-3 py-2 text-sm">
            {TYPES.map((t) => (
              <option key={t} value={t}>{t.replace("_", " ")}</option>
            ))}
          </select>
          <button
            onClick={createIncident}
            disabled={loading || !title.trim()}
            className="ml-auto px-4 py-2 bg-emerald-500 text-[#0a0a0a] rounded-lg text-sm font-medium hover:bg-emerald-400 active:scale-[0.98] disabled:opacity-40 transition"
          >
            {loading ? "Creating…" : "Create"}
          </button>
        </div>
        {error && <p className="text-red-400 text-sm">{error}</p>}
      </section>

      {/* List */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-medium text-neutral-500 uppercase tracking-wider">Active incidents</h2>
          <span className="text-[11px] text-neutral-600">{incidents.length}</span>
        </div>

        {incidents.length === 0 && (
          <div className="rounded-xl border border-dashed border-white/[0.08] py-12 text-center">
            <p className="text-sm text-neutral-500">No incidents yet</p>
            <p className="text-[11px] text-neutral-600 mt-1">Create one above or receive a signal</p>
          </div>
        )}

        {incidents.map((inc) => (
          <article
            key={inc.id}
            className={`rounded-xl border bg-neutral-900/30 p-4 space-y-3 transition-all duration-300 ${
              justCreated === inc.id
                ? "border-emerald-500/40 ring-1 ring-emerald-500/20"
                : "border-white/[0.06]"
            }`}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0 flex items-start gap-2.5">
                <span className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${severityDot(inc.severity)}`} />
                <div className="min-w-0">
                  <h3 className="font-medium truncate">{inc.title}</h3>
                  {inc.summary && <p className="text-sm text-neutral-400 mt-1 line-clamp-2">{inc.summary}</p>}
                </div>
              </div>
              <span className={`text-[11px] px-2 py-0.5 rounded-md capitalize shrink-0 ${badge(inc.severity)}`}>
                {inc.severity}
              </span>
            </div>
            <div className="text-[11px] text-neutral-500 flex flex-wrap gap-x-4 gap-y-1 pl-4">
              <span>{inc.status}</span>
              {inc.incident_type && <span>{inc.incident_type.replace("_", " ")}</span>}
              {inc.response_sla_minutes != null && <span>SLA {inc.response_sla_minutes} min</span>}
              <span>{new Date(inc.created_at).toLocaleString()}</span>
            </div>
            {decisionFor === inc.id ? (
              <div className="flex gap-2 pt-1 pl-4">
                <input
                  value={decisionText}
                  onChange={(e) => setDecisionText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && recordDecision(inc.id)}
                  placeholder="Record decision…"
                  autoFocus
                  className="flex-1 bg-black/40 border border-white/[0.08] rounded-lg px-3 py-1.5 text-sm outline-none focus:border-emerald-500/50"
                />
                <button onClick={() => recordDecision(inc.id)} disabled={decisionLoading || !decisionText.trim()} className="px-3 py-1.5 bg-emerald-500 text-[#0a0a0a] rounded-lg text-xs font-medium disabled:opacity-40">
                  Save
                </button>
                <button onClick={() => setDecisionFor(null)} className="text-xs text-neutral-500 px-2">Cancel</button>
              </div>
            ) : (
              <button
                onClick={() => { setDecisionFor(inc.id); setDecisionText(""); }}
                className="text-xs text-neutral-400 hover:text-white transition pl-4"
              >
                + Record decision
              </button>
            )}
          </article>
        ))}
      </section>
    </div>
  );
}
