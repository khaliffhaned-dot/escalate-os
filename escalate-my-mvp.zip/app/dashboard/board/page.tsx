import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import Link from "next/link";
import { getDb, getSession } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function BoardBriefPage() {
  const token = cookies().get("session")?.value;
  const session = await getSession(token);
  if (!session) redirect("/login");

  const db = await getDb();
  const { results: incidents } = await db
    .prepare(
      `SELECT i.id, i.title, i.severity, i.status, i.created_at,
              (SELECT COUNT(*) FROM decisions d WHERE d.incident_id = i.id) as decision_count
       FROM incidents i WHERE i.tenant_id = ? ORDER BY i.created_at DESC LIMIT 30`
    )
    .bind(session.tenant_id)
    .all();

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-neutral-100 print:bg-white print:text-black">
      <header className="border-b border-white/[0.06] px-6 py-3.5 sticky top-0 bg-[#0a0a0a]/80 backdrop-blur-xl z-10 print:hidden">
        <Link href="/dashboard" className="text-xs text-neutral-500 hover:text-white transition">← Situation Room</Link>
        <h1 className="text-base font-semibold mt-1">BoardBrief</h1>
        <p className="text-[11px] text-neutral-500">Open incidents · Severity · Decisions · Status · Use browser print to export</p>
      </header>
      <div className="max-w-4xl mx-auto p-6">
        <div className="rounded-xl border border-white/[0.06] overflow-hidden print:border-neutral-300">
          <table className="w-full text-sm">
            <thead className="bg-neutral-900/60 text-neutral-500 text-[11px] uppercase tracking-wider print:bg-neutral-100 print:text-black">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Incident</th>
                <th className="text-left px-4 py-3 font-medium">Severity</th>
                <th className="text-left px-4 py-3 font-medium">Status</th>
                <th className="text-left px-4 py-3 font-medium">Decisions</th>
                <th className="text-left px-4 py-3 font-medium">Opened</th>
              </tr>
            </thead>
            <tbody>
              {(incidents || []).map((inc: any) => (
                <tr key={inc.id} className="border-t border-white/[0.06] print:border-neutral-200">
                  <td className="px-4 py-3">{inc.title}</td>
                  <td className="px-4 py-3 capitalize">{inc.severity}</td>
                  <td className="px-4 py-3">{inc.status}</td>
                  <td className="px-4 py-3">{inc.decision_count}</td>
                  <td className="px-4 py-3 text-neutral-500 print:text-neutral-600">{new Date(inc.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
              {(!incidents || incidents.length === 0) && (
                <tr><td colSpan={5} className="px-4 py-10 text-center text-neutral-600">No incidents</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <p className="text-[11px] text-neutral-600 mt-4">Generated {new Date().toLocaleString()} · Escalate MY BoardBrief</p>
      </div>
    </div>
  );
}
