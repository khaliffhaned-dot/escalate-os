"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("demo@escalate.local");
  const [password, setPassword] = useState("demo");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      router.push("/dashboard");
      router.refresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#0a0a0a] text-neutral-100 flex items-center justify-center p-6 relative">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[400px] h-[400px] bg-emerald-500/[0.06] rounded-full blur-3xl" />
      </div>
      <form onSubmit={submit} className="relative w-full max-w-sm space-y-5 rounded-2xl border border-white/[0.08] bg-neutral-900/60 backdrop-blur-xl p-7">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-[#0a0a0a] text-sm font-bold">E</div>
          <div>
            <h1 className="text-base font-semibold">Sign in</h1>
            <p className="text-[11px] text-neutral-500">Escalate MY · Crisis Governance</p>
          </div>
        </div>
        <div className="space-y-3">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full bg-black/40 border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500/40 transition"
            required
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full bg-black/40 border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500/40 transition"
            required
          />
        </div>
        {error && <p className="text-red-400 text-sm">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 bg-emerald-500 text-[#0a0a0a] rounded-lg text-sm font-medium hover:bg-emerald-400 disabled:opacity-50 transition"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
        <p className="text-[11px] text-neutral-600 text-center">Demo · demo@escalate.local / demo</p>
      </form>
    </main>
  );
}
