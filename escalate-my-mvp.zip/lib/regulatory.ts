export type RegulatoryClock = {
  regulator: string;
  shortName: string;
  typicalWindow: string;
  notes: string;
  source: string;
};

export const REGULATORY_CLOCKS: RegulatoryClock[] = [
  {
    regulator: "Bank Negara Malaysia (BNM)",
    shortName: "BNM RMiT",
    typicalWindow: "2 hours (major tech/cyber)",
    notes: "Major technology or cyber incidents. Other disruptions generally 24 hours. Confirm with current RMiT guidance.",
    source: "BNM Risk Management in Technology",
  },
  {
    regulator: "Personal Data Protection Commissioner",
    shortName: "PDPA",
    typicalWindow: "As soon as practicable, generally ≤72 hours",
    notes: "Qualifying personal data breaches. Documentation and notification obligations apply.",
    source: "PDPA and related guidance",
  },
  {
    regulator: "Bursa Malaysia",
    shortName: "Bursa",
    typicalWindow: "Same-day announcement (material information)",
    notes: "Listed issuers. Immediate announcement of material information. Confirm with Listing Requirements.",
    source: "Bursa Malaysia Listing Requirements",
  },
  {
    regulator: "National Cyber Security Agency",
    shortName: "NACSA",
    typicalWindow: "Organisation-defined / sector guidance",
    notes: "Critical information infrastructure and related reporting expectations. Confirm with current NACSA guidance.",
    source: "NACSA frameworks",
  },
  {
    regulator: "Department of Occupational Safety and Health",
    shortName: "DOSH",
    typicalWindow: "Immediate / statutory notification",
    notes: "Workplace incidents involving injury or dangerous occurrence. Statutory notification rules apply.",
    source: "OSHA and DOSH regulations",
  },
  {
    regulator: "Department of Environment",
    shortName: "DOE",
    typicalWindow: "Immediate notification (prescribed incidents)",
    notes: "Environmental incidents. Confirm prescribed notification timelines.",
    source: "Environmental Quality Act and regulations",
  },
  {
    regulator: "Malaysian Anti-Corruption Commission",
    shortName: "MACC",
    typicalWindow: "Organisation policy + statutory",
    notes: "Corruption or related allegations. Internal escalation and external reporting per policy and law.",
    source: "MACC Act and organisational policy",
  },
  {
    regulator: "Malaysian Communications and Multimedia Commission",
    shortName: "MCMC",
    typicalWindow: "As required under CMA / guidelines",
    notes: "Communications and multimedia sector incidents. Confirm current MCMC requirements.",
    source: "Communications and Multimedia Act",
  },
  {
    regulator: "Ministry of Health",
    shortName: "MOH",
    typicalWindow: "Immediate / statutory",
    notes: "Public health and healthcare facility incidents. Confirm sector-specific rules.",
    source: "MOH guidelines",
  },
  {
    regulator: "Department of Islamic Development Malaysia",
    shortName: "JAKIM",
    typicalWindow: "Organisation / certification body rules",
    notes: "Halal and related compliance incidents. Confirm with certification body requirements.",
    source: "JAKIM and certification requirements",
  },
];

export const SEVERITY_SLA: Record<string, { label: string; minutes: number; description: string }> = {
  critical: { label: "T1 Critical", minutes: 120, description: "Safety, major regulatory, criminal, mass media, executive misconduct" },
  serious: { label: "T2 Serious", minutes: 360, description: "Significant reputational, material service failure, investor impact" },
  moderate: { label: "T3 Moderate", minutes: 1440, description: "Limited media, single stakeholder, minor operational" },
  minor: { label: "T4 Minor", minutes: 2880, description: "Social commentary, no material external visibility" },
};
